Tested with AAPL, GOOG, TSLA. Historical data csv should be in the same directory.

To run the file

	python filename.py historical_file.csv

	Linux: python3 evolution-strategy-bayesian-agent.py AAPL.csv
	
	Windows: python evolution-strategy-bayesian-agent.py AAPL.csv

Critical pip or pip3 requirement:

	Tensorflow >= 2.0
	bayesian-optimization

predicted CSV files are saved with script_name.csv
